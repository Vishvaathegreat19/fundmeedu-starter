// FundMeEdu App (React Native with Expo) - Tab Navigation + Campaign Details + Donation Simulation

import React, { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { enableScreens } from "react-native-screens";

// Enable react-native-screens for better performance
enableScreens();

const Tab = createBottomTabNavigator();

function HomeScreen({ ageGroup, campaigns, setSelectedCampaign, setAgeGroup }) {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>
        Dashboard – {ageGroup === "secondary" ? "Secondary" : "College"} Student
      </Text>
      {campaigns.map((c) => (
        <TouchableOpacity
          key={c.id}
          style={styles.card}
          onPress={() => setSelectedCampaign(c)}
        >
          <Text style={styles.cardTitle}>{c.title}</Text>
          <Text>Goal: ${c.goal} | Raised: ${c.raised}</Text>
          <Text numberOfLines={1}>{c.desc}</Text>
        </TouchableOpacity>
      ))}
      {!ageGroup && (
        <View style={{ marginTop: 20 }}>
          <Button title="🎒 I'm in Secondary School" onPress={() => setAgeGroup("secondary")} />
          <Button title="🎓 I'm in College / University" onPress={() => setAgeGroup("college")} />
        </View>
      )}
    </ScrollView>
  );
}

function CreateScreen({ handleCreate }) {
  const [form, setForm] = useState({ title: "", goal: "", desc: "" });

  const handleInput = (name, value) => {
    setForm({ ...form, [name]: value });
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>Create Campaign</Text>
      <TextInput
        style={styles.input}
        placeholder="Title"
        value={form.title}
        onChangeText={(text) => handleInput("title", text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Goal Amount"
        keyboardType="numeric"
        value={form.goal}
        onChangeText={(text) => handleInput("goal", text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Description"
        multiline
        value={form.desc}
        onChangeText={(text) => handleInput("desc", text)}
      />
      <Button
        title="Submit"
        onPress={() => {
          if (form.title && form.goal) {
            handleCreate(form);
            setForm({ title: "", goal: "", desc: "" });
          }
        }}
      />
    </ScrollView>
  );
}

function ProfileScreen({ campaigns }) {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>My Campaigns</Text>
      {campaigns.map((c) => (
        <View key={c.id} style={styles.card}>
          <Text style={styles.cardTitle}>{c.title}</Text>
          <Text>Goal: ${c.goal} | Raised: ${c.raised}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

function CampaignDetailScreen({ selectedCampaign, handleDonate, goBack }) {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>{selectedCampaign?.title}</Text>
      <Text style={{ marginBottom: 10 }}>{selectedCampaign?.desc}</Text>
      <Text>Goal: ${selectedCampaign?.goal}</Text>
      <Text>Raised: ${selectedCampaign?.raised}</Text>
      <Button
        title="Donate $1"
        onPress={() => handleDonate(selectedCampaign.id)}
      />
      <Button title="Back to Dashboard" onPress={goBack} />
    </View>
  );
}

export default function App() {
  const [ageGroup, setAgeGroup] = useState(null);
  const [campaigns, setCampaigns] = useState([]);
  const [selectedCampaign, setSelectedCampaign] = useState(null);

  const handleCreate = (campaign) => {
    setCampaigns([...campaigns, { ...campaign, id: campaigns.length + 1, raised: 0 }]);
  };

  const handleDonate = (id) => {
    setCampaigns((prev) =>
      prev.map((c) => (c.id === id ? { ...c, raised: c.raised + 1 } : c))
    );
    setSelectedCampaign((prev) => ({ ...prev, raised: prev.raised + 1 }));
  };

  return (
    <NavigationContainer>
      {selectedCampaign ? (
        <CampaignDetailScreen
          selectedCampaign={selectedCampaign}
          handleDonate={handleDonate}
          goBack={() => setSelectedCampaign(null)}
        />
      ) : (
        <Tab.Navigator>
          <Tab.Screen name="Home">
            {() => (
              <HomeScreen
                ageGroup={ageGroup}
                campaigns={campaigns}
                setSelectedCampaign={setSelectedCampaign}
                setAgeGroup={setAgeGroup}
              />
            )}
          </Tab.Screen>
          <Tab.Screen name="Create">
            {() => <CreateScreen handleCreate={handleCreate} />}
          </Tab.Screen>
          <Tab.Screen name="Profile">
            {() => <ProfileScreen campaigns={campaigns} />}
          </Tab.Screen>
        </Tab.Navigator>
      )}
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff"
  },
  header: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center"
  },
  input: {
    width: "100%",
    padding: 10,
    borderWidth: 1,
    marginBottom: 15,
    borderRadius: 5
  },
  card: {
    padding: 15,
    backgroundColor: "#f0f0f0",
    marginBottom: 10,
    width: "100%",
    borderRadius: 8
  },
  cardTitle: {
    fontWeight: "bold",
    fontSize: 16
  }
});
